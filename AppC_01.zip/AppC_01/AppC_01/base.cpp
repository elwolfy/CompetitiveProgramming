#include <iostream>
#include <conio.h>
#include "lis_01.cpp"
/*
DOMINIO: PROGRAMACION DINAMICA - INTELIGENCIA ARTIFICIAL
TITULO: LONGEST INCREASING SUBSEQUENCE (LIS)
DESCRIPCION: RECURSOS PARA PROGRAMACION COMPETITIVA ACM 2017 https://www.codechef.com/icpc/2017
AUTOR: MSC. ING. JORGE VALENZUELA POSADAS
TWTTER: @el_wolfy  MAIL: jvalenzuelap@gmail.com
CELULAR: 511-997436920
WEB: www.cps-tech.com
FECHA: 17/12/2016
*/
using namespace std;

int main()
{

	lis_01 oObj;
	const int N=8;
	int X[N];
	int LIS[N];
	int LISFinal[N];
	int cont=0;


	printf("Ingrese una secuencia de %i numeros: \n", N);
	for (int i = 0; i<N; i++) {
		scanf("%i", &X[i]);
	}

	LIS[0] = 1;
	LISFinal[cont] = X[0];
	int ans = 1;
	for (int i = 0; i<N; i++) {
		for (int j = 0; j<i; j++) {
			if (X[i]>X[j])
			{
				ans = fmax(ans, 1 + LIS[j]);
			}
		}
		LIS[i] = ans;
	}

	for (int i = 1; i <N-1; i++) {
		if (LIS[i] == LIS[i - 1]) {
			//buscar el mayor
			LISFinal[cont] = fmin(X[i], X[i - 1]);
		}
		else {
			//cargarlo
			cont++;
			LISFinal[cont] = X[i];
		}
	}


	printf("RESULTADOS\n");
	printf("==========\n");
	printf("Indice \t X \t LIS[indice] \n");
	for (int i = 0; i <N; i++) {
		printf("%i \t %i \t %i \n", i, X[i], LIS[i]);
	}

	printf("El longest Increasing Subsequence LIS es: \n");
	for (int i = 0; i<=cont; i++) {		
		printf("%i \n", LISFinal[i]);
	}
	/*
	for (int i = 0; i<N; i++) {
		printf("%i", LIS[i]);
	}
	*/


	_getch();
	return 0;
}
