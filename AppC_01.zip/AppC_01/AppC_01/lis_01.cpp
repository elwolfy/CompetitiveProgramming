#include <iostream>
#include <conio.h>

using namespace std;

class lis_01 {

public:
	int suma(int num1, int num2) {
		return num1 + num2;
	}
};